package com.edu.BlockchainCybersecurityServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlockchainCybersecurityServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlockchainCybersecurityServerApplication.class, args);
	}
	//curl -X POST -H "Content-Type: text/plain" -d "CREATE TABLE example (id INT, name VARCHAR(255));" http://localhost:8080/api/sql/execute
}
