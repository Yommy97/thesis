package com.edu.BlockchainCybersecurityServer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/sql")
public class SqlExecutionController {
    private final Logger logger = LoggerFactory.getLogger(SqlExecutionController.class);

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public SqlExecutionController(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @PostMapping("/execute")
    public String executeSqlScript(@RequestBody String sqlScript) {
        logger.info("Received SQL script: {}", sqlScript);
        try {
            jdbcTemplate.execute(sqlScript);
            return "SQL script executed successfully.";
        } catch (Exception e) {
            return "Error executing SQL script: " + e.getMessage();
        }
    }
}
