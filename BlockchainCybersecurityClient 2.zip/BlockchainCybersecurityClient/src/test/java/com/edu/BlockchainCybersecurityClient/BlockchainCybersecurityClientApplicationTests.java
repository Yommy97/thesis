package com.edu.BlockchainCybersecurityClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlockchainCybersecurityClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
