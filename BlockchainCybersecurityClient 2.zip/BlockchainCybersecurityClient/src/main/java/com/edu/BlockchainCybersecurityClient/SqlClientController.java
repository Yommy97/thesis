package com.edu.BlockchainCybersecurityClient;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class SqlClientController {
    private final Logger logger = LoggerFactory.getLogger(SqlClientController.class);

    @Autowired private SqlClientService sqlClientService;

    @GetMapping("/executeSql")
    public String showExecuteSqlPage() {
        return "executeSql";
    }

    @PostMapping("/executeSql")
    public String executeSqlScript(String sqlScript, Model model) {
        logger.info("Received SQL script: {}", sqlScript);
        String serverResponse = sqlClientService.executeSqlScript(sqlScript);
        logger.info("Response received from server: {}", serverResponse);
        model.addAttribute("serverResponse", serverResponse);
        return "executeSql"; // Return the same page for now
    }
}
