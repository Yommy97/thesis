package com.edu.BlockchainCybersecurityClient;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@PropertySource("classpath:application.properties")
public class SqlClientService {

    @Value("${server.base-url}")
    private  String serverBaseUrl = "http://localhost:8080";

    public String executeSqlScript(String sqlScript) {
        try {
            // Set the endpoint URL on the server that handles SQL execution
            String endpointUrl = serverBaseUrl + "/api/sql/execute";

            // Create a RestTemplate instance
            RestTemplate restTemplate = new RestTemplate();

            // Set headers
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.TEXT_PLAIN);

            // Set the request entity, including the SQL script in the request body
            HttpEntity<String> requestEntity = new HttpEntity<>(sqlScript, headers);

            // Make the POST request and get the response
            ResponseEntity<String> responseEntity = restTemplate.exchange(
                    endpointUrl,
                    HttpMethod.POST,
                    requestEntity,
                    String.class
            );

            // Check if the request was successful (HTTP status code 2xx)
            if (responseEntity.getStatusCode().is2xxSuccessful()) {
                return responseEntity.getBody();
            } else {
                return "Error: " + responseEntity.getStatusCodeValue() + " - " + responseEntity.getBody();
            }
        } catch (Exception e) {
            return "Error executing SQL script: " + e.getMessage();
        }
    }

//    public static void main(String[] args) {
//        SqlClientService sqlClientService = new SqlClientService();
//
//        // Example SQL script
//        String sqlScript = "CREATE TABLE example (id INT, name VARCHAR(255));";
//
//        // Call the server and print the response
//        String serverResponse = sqlClientService.executeSqlScript(sqlScript);
//        System.out.println("Server Response: " + serverResponse);
//    }
}

