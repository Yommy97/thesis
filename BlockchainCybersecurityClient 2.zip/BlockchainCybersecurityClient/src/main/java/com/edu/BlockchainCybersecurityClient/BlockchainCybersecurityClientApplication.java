package com.edu.BlockchainCybersecurityClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlockchainCybersecurityClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlockchainCybersecurityClientApplication.class, args);
	}

}
